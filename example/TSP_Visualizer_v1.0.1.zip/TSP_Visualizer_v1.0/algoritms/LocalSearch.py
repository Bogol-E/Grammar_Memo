import itertools
from util import *


class LocalSearchSolver:
    def __init__(self, cities, order, d):
        self.cities = cities
        self.total = len(cities)
        self.best_order = order[:]
        self.best_distance = calc_path_distance(self.cities, self.best_order)
        self.d = d

    def foo(self, bestO, bestD):
        indexList = [i for i in range(self.total)]
        for indices in itertools.combinations(indexList, self.d):
            copyO = bestO[:]
            indices = list(indices)
            c = [copyO[i] for i in indices]
            for shuffled in itertools.permutations(c):
                currOrder = copyO[:]
                for i, num in zip(indices, shuffled):
                    currOrder[i] = num
                d = calc_path_distance(self.cities, currOrder)
                if d < bestD:
                    bestD = d
                    bestO = currOrder
        return bestO, bestD

    def find(self):
        o, d = self.best_order, self.best_distance
        o, d = self.foo(o, d)
        while o != self.best_order and d != self.best_distance:
            o, d = self.foo(o, d)
            if d < self.best_distance:
                self.best_distance = d
                self.best_order = o
