# TSP 시각화

> TSP 관련 알고리즘을 시각적으로 확인할 수 있는 방법을 제시

## 설정
* Python <= 3.10
* pygame

```bash
$ pip install pygame
$ python main.py
```